package com.sai.spring.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sai.spring.springmvc.dto.User;

@Controller
public class UserController {

//	@RequestMapping("/regPage")
//	public ModelAndView showPage() {
//		ModelAndView modelAndView = new ModelAndView();
//		modelAndView.setViewName("userReg");
//
//		return modelAndView;
//
//	}

// here we not use any data so we only view to reduce code
	@RequestMapping("/regPage")
	public String showPage() {

		return "userReg";

	}

//	@RequestMapping(value = "registerUser", method = RequestMethod.POST)
//	public ModelAndView registerUser(@ModelAttribute("userdata") User user) {
//		System.out.println(user);
//		ModelAndView modelAndView = new ModelAndView();
//		modelAndView.addObject("user", user);
//		modelAndView.setViewName("regResult");
//
//		return modelAndView;
//
//	}

	// another wayy
	@RequestMapping(value = "registerUser", method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("userdata") User user, ModelMap model) {
		System.out.println(user);
		model.addAttribute("user", user);
		return "regResult";

	}
}
